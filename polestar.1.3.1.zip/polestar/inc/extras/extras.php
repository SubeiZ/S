<?php	

/**
 * Load all the extra components.
 */
require get_template_directory() . '/inc/extras/about-page.php';
require get_template_directory() . '/inc/extras/page-settings.php';
