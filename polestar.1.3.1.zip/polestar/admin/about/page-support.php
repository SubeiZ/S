<h3><?php esc_html_e( 'Professional Support', 'polestar' ); ?></h3>
<p>
	<?php printf( esc_html__( "Keep your project moving forward with quick support on our %sfree support forums%s. Beginner or advanced user, we're here to help.", 'polestar' ), '<a href="https://purothemes.com/support/forum/polestar-theme/">', '</a>' ); ?>
</p>
