<h3><?php esc_html_e( 'Enhanced by Page Builder', 'polestar' ); ?></h3>
<p>
	<?php printf( esc_html__( "Polestar integrates, beautifully, with %sPage Builder by SiteOrigin%s.", 'polestar' ), '<a href="https://siteorigin.com/page-builder/">', '</a>' ); ?>
	<?php esc_html_e( 'This powerful plugin gives you full drag and drop capabilities right inside Polestar.', 'polestar' ); ?>
</p>
