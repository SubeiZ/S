Place your theme language files in this directory.

Please visit the following links to learn more about translating WordPress themes:

https://codex.wordpress.org/Translating_WordPress
https://codex.wordpress.org/Function_Reference/load_theme_textdomain
